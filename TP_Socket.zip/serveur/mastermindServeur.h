#define LmaxSeq 4

void initialisation(int sequenceSecrete[LmaxSeq], int niveauDiff) ;

void tentative(int seq[LmaxSeq],int sequenceSecrete[LmaxSeq], int* reponse, int*L, int nbTours);

