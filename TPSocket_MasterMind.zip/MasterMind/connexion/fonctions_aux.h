

void sendMessage ( int socket , char str[] ) ;
void lireMessage ( int socket , char * str) ;