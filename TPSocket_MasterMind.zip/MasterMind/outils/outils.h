

#define STR_SIZE 1000

void strToSeqInt ( char str[] , int* Seq, int* L) ;
void seqIntToStr ( int* Seq, int L, char *str ) ;
void strlwr (char *str ) ;