

int strEnFormat(char *str, int nvDiff) ;

int digitsOnly(char *s) ;

int intoRange(char *s, int a, int b) ;

int coleurEnJeu (char * word, int nvDiff) ;